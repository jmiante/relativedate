from setuptools import setup

setup(
    name='relativedate',
    version='0.1.0',
    description='Pacote Python para Datas Relativas, o projeto está iniciando, porém com o tempo traremos grandes melhorias',
    packages=['relativedate'],
    install_requires=[],
)
